import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/cso.json";
const CSOPage = () => <DetailCompetition data={data} />;

export default CSOPage;
