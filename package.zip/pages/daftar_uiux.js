import React from "react";
import Router from "next/router";
const DaftarUIUX = () => {
  React.useEffect(() => {
    const { pathname } = Router;
    Router.replace("//forms.gle/WDVkyWwLnqh21Z5h7");
  }, []);
  return <h1>Redirect ke Pendaftaran</h1>;
};

export default DaftarUIUX;
