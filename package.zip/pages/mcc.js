import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/mcc.json";
const MCCPage = () => <DetailCompetition data={data} />;

export default MCCPage;
