import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/uiux.json";
const UIUXPage = () => <DetailCompetition data={data} />;

export default UIUXPage;
