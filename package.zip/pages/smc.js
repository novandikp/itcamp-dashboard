import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/smc.json";
const SMCPage = () => <DetailCompetition data={data} />;

export default SMCPage;
