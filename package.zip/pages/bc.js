import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/bc.json";
const BCPage = () => <DetailCompetition data={data} />;

export default BCPage;
