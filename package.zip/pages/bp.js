import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/bp.json";
const BPPage = () => <DetailCompetition data={data} />;

export default BPPage;
