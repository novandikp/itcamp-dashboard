import Layout from "../components/Layout";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import Banner from "../components/Banner";
import Events from "../components/Events";
import Video from "../components/Video";
import MediaPartner from "../components/MediaPartner";
import Section from "../components/Section";
import Subscribe from "../components/Subscribe";
import { competition, header, video } from "../public/assets/data/index.json";
const HomePage = () => {
  return (
    <Layout pageTitle="Fasilkom Fest">
      <Navigation competition={competition} />
      <Banner header={header} />
      <Events competition={competition} title={header.nama_lomba} />
      <Video data={video} />
      <Section competition={competition} />
      <MediaPartner />
      <Footer />
    </Layout>
  );
};

export default HomePage;
