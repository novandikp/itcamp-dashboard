import DetailCompetition from "../components/DetailCompetition";
import data from "../public/assets/data/pgc.json";
const PGCPage = () => <DetailCompetition data={data} />;

export default PGCPage;
