import React from "react";
import Swiper from "react-id-swiper";
import "swiper/css/swiper.css";

const MediaPartner = () => {
  return (
    <div className="brand-one my-5 py-5">
      <div className="container">
        <div className="block-title text-center">
          <h2 className="block-title__title">
            <span>Media Partner</span>
          </h2>
        </div>
        <div className="row">
          <div className="item col-lg-3 col-6 text-center">
            <img
              className="img-fluid w-75"
              src="/assets/images/resources/brand-1-1.png"
              alt=""
            />
          </div>
          <div className="item col-lg-3 col-6 text-center">
            <img
              className="img-fluid w-75"
              src="/assets/images/resources/brand-1-1.png"
              alt=""
            />
          </div>
          <div className="item col-lg-3 col-6 text-center">
            <img
              className="img-fluid w-75"
              src="/assets/images/resources/brand-1-1.png"
              alt=""
            />
          </div>
          <div className="item col-lg-3 col-6 text-center">
            <img
              className="img-fluid w-75"
              src="/assets/images/resources/brand-1-1.png"
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
};
export default MediaPartner;
