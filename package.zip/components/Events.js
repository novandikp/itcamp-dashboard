import React from "react";
import parser from "react-html-parser";
const Events = ({ title, competition }) => {
  return (
    <section className="service-one" id="features">
      <div className="container">
        <div className="block-title text-center ">
          <h2 className="block-title__title ">
            Semua acara di {parser(title)}
          </h2>
          <p className="banner-one__text ">
            Lihat dan tunggu semua acara - acara kami.
          </p>
        </div>
        <div className="row">
          {competition.map((lomba, index) => {
            return (
              <div
                key={index}
                className="col-lg-4 col-sm-12 wow fadeInDown"
                data-wow-duration="1500ms"
              >
                <div className="service-one__single text-center">
                  <div className="service-one__inner">
                    <img
                      className="img-responsive py-5 w-50"
                      src={"/assets/images/resources/" + lomba.logo}
                    />
                    <h3>
                      <a href="#">{lomba.nama}</a>
                    </h3>
                    <br />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
export default Events;
